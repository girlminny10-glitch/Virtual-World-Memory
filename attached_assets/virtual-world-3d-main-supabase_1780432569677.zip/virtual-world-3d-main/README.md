# 🌍 Virtual World 3D

Um mundo virtual 3D interativo com NPCs controlados por IA em tempo real. Explore, construa e converse com personagens autônomos em um ambiente dinâmico!

## ✨ Funcionalidades

- **Mundo 3D Imersivo**: Renderizado com Three.js
- **18 NPCs Autônomos**: Controlados por IA (OpenAI GPT)
- **Conversas em Tempo Real**: Chat com NPCs via WebSocket
- **Construção Dinâmica**: NPCs e o jogador podem criar estruturas (casas, torres, fontes, jardins)
- **Movimento Fluido**: Controles intuitivos (teclado ou joystick mobile)
- **Minimap**: Visualize a posição de todos no mapa
- **Feed de Eventos**: Acompanhe todas as interações em tempo real
- **Histórico de 30 Mensagens**: Releia conversas passadas

## 🎮 Como Jogar

### Controles Desktop
- **W/A/S/D**: Mover seu personagem
- **Mouse**: Girar câmera (arraste)
- **Clique**: Conversar com NPCs
- **Scroll**: Zoom da câmera

### Controles Mobile
- **Joystick (canto inferior esquerdo)**: Mover
- **Deslizar lado direito**: Girar câmera
- **Toque no NPC**: Conversar
- **Botões (canto inferior direito)**: Construir estruturas

## 🏗️ Construir

Você pode construir 4 tipos de estruturas:
- 🏠 **Casa**: Uma estrutura residencial
- 🗼 **Torre**: Uma torre alta
- ⛲ **Fonte**: Uma fonte de água
- 🌸 **Jardim**: Um jardim com flores

Basta clicar nos botões no canto inferior direito!

## 🤖 NPCs

O mundo possui 18 NPCs únicos, cada um com:
- Personalidade própria
- Comportamento autônomo
- Capacidade de criar estruturas
- Conversas dinâmicas com IA

**NPCs Disponíveis**: Alex, Jordan, Luna, Marcus, Zara, Kai, Ivy, Dante, Aria, Leo, Mya, Rex, Zoe, Finn, Lia, Hugo, Sola, Nox

## 🛠️ Instalação Local

```bash
# Clonar repositório
git clone https://github.com/seu-usuario/virtual-world-3d.git
cd virtual-world-3d

# Instalar dependências
npm install

# Configurar variáveis de ambiente
cp .env.example .env
# Edite .env e adicione sua OPENAI_API_KEY

# Iniciar servidor
npm start

# Acesse em http://localhost:3001
```

## 📦 Requisitos

- Node.js 18+
- npm ou yarn
- Chave de API OpenAI

## 🚀 Deploy no Railway

1. Faça push do código para GitHub
2. Acesse [railway.app](https://railway.app)
3. Conecte seu repositório GitHub
4. Configure variáveis de ambiente (OPENAI_API_KEY)
5. Deploy automático!

## 🏗️ Arquitetura

### Backend
- **Express.js**: Servidor HTTP
- **WebSocket**: Comunicação em tempo real
- **OpenAI API**: IA para NPCs

### Frontend
- **Three.js**: Motor 3D
- **Vanilla JavaScript**: Sem dependências desnecessárias
- **HTML5 Canvas**: Renderização

## 📝 Variáveis de Ambiente

```
OPENAI_API_KEY=sua-chave-aqui
PORT=3001
```

## 🎯 Próximas Melhorias

- [ ] Banco de dados para persistência
- [ ] Sistema de inventário
- [ ] Mais mapas/cidades
- [ ] Achievements
- [ ] Chat por voz
- [ ] Multiplayer avançado

## 📄 Licença

MIT

## 👤 Autor

Criado com ❤️ para Minny

---

**Versão**: 1.0.0  
**Status**: ✅ Completo e Pronto para Produção
