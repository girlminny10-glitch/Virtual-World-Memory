require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const OpenAI = require('openai');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
  baseURL: process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1'
});

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// ─── Estado do Mundo ────────────────────────────────────────────────────────
const WORLD_SIZE = 120;

const npcs = {
  'npc-1': { id: 'npc-1', name: 'Alex',   color: '#FF6B6B', position: { x: 15,  z: 15  }, emotion: 'feliz',      personality: 'Otimista, amigável e aventureiro.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'explorando', createdThings: [] },
  'npc-2': { id: 'npc-2', name: 'Jordan', color: '#4ECDC4', position: { x: -20, z: 10  }, emotion: 'pensativo',  personality: 'Inteligente, analítico e misterioso.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'meditando', createdThings: [] },
  'npc-3': { id: 'npc-3', name: 'Luna',   color: '#FFE66D', position: { x: 30,  z: -25 }, emotion: 'criativo',   personality: 'Artística, sonhadora e criativa.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'pintando', createdThings: [] },
  'npc-4': { id: 'npc-4', name: 'Marcus', color: '#A8E6CF', position: { x: -35, z: -20 }, emotion: 'sério',      personality: 'Sério, lógico e disciplinado.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'construindo', createdThings: [] },
  'npc-5': { id: 'npc-5', name: 'Zara',   color: '#FF8B94', position: { x: 45,  z: 25  }, emotion: 'animado',    personality: 'Energética e competitiva.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'treinando', createdThings: [] },
  'npc-6': { id: 'npc-6', name: 'Kai',    color: '#B8B8FF', position: { x: -45, z: 35  }, emotion: 'calmo',      personality: 'Calmo, sábio e contemplativo.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'observando', createdThings: [] },
  'npc-7': { id: 'npc-7', name: 'Ivy',    color: '#FFDAC1', position: { x: 55,  z: -35 }, emotion: 'misterioso', personality: 'Misteriosa e enigmática.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'escrevendo', createdThings: [] },
  'npc-8': { id: 'npc-8', name: 'Dante',  color: '#E2F0CB', position: { x: -55, z: -45 }, emotion: 'apaixonado', personality: 'Apaixonado e expressivo.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'compondo', createdThings: [] },
  'npc-9': { id: 'npc-9', name: 'Aria',   color: '#FF9FF3', position: { x: 10,  z: -50 }, emotion: 'alegre',     personality: 'Musical e vibrante.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'cantando', createdThings: [] },
  'npc-10': { id: 'npc-10', name: 'Leo',  color: '#FECA57', position: { x: -10, z: 50  }, emotion: 'corajoso',   personality: 'Líder nato e protetor.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'patrulhando', createdThings: [] },
  'npc-11': { id: 'npc-11', name: 'Mya',  color: '#48DBFB', position: { x: 60,  z: 10  }, emotion: 'curiosa',    personality: 'Curiosa e rápida.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'correndo', createdThings: [] },
  'npc-12': { id: 'npc-12', name: 'Rex',  color: '#1DD1A1', position: { x: -60, z: -10 }, emotion: 'firme',      personality: 'Robusto e prático.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'minerando', createdThings: [] },
  'npc-13': { id: 'npc-13', name: 'Zoe',  color: '#FF6B6B', position: { x: 25,  z: 40  }, emotion: 'gentil',     personality: 'Amável e prestativa.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'ajudando', createdThings: [] },
  'npc-14': { id: 'npc-14', name: 'Finn', color: '#54A0FF', position: { x: -25, z: -40 }, emotion: 'ágil',      personality: 'Brincalhão e veloz.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'saltando', createdThings: [] },
  'npc-15': { id: 'npc-15', name: 'Lia',  color: '#5F27CD', position: { x: 40,  z: -60 }, emotion: 'mística',    personality: 'Espiritual e profunda.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'meditando', createdThings: [] },
  'npc-16': { id: 'npc-16', name: 'Hugo', color: '#EE5253', position: { x: -40, z: 60  }, emotion: 'forte',      personality: 'Trabalhador e resiliente.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'carregando pedras', createdThings: [] },
  'npc-17': { id: 'npc-17', name: 'Sola', color: '#F368E0', position: { x: 0,   z: 0   }, emotion: 'radiante',   personality: 'Solar e positiva.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'dançando', createdThings: [] },
  'npc-18': { id: 'npc-18', name: 'Nox',  color: '#222F3E', position: { x: 70,  z: 70  }, emotion: 'sombrio',    personality: 'Noturno e silencioso.', conversationHistory: [], isMoving: false, targetPosition: null, currentAction: 'espreitando', createdThings: [] },
};

const players = {};
const worldObjects = []; // objetos criados pelos NPCs
let worldObjectIdCounter = 1;

// ─── Broadcast ───────────────────────────────────────────────────────────────
function broadcast(data, excludeWs = null) {
  const msg = JSON.stringify(data);
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN && client !== excludeWs) {
      client.send(msg);
    }
  });
}

function broadcastAll(data) {
  broadcast(data, null);
}

// ─── IA dos NPCs ─────────────────────────────────────────────────────────────
const EMOTIONS = ['feliz', 'pensativo', 'animado', 'calmo', 'curioso', 'surpreso', 'misterioso', 'criativo', 'sério', 'apaixonado'];

function randomPos() {
  return {
    x: (Math.random() - 0.5) * WORLD_SIZE,
    z: (Math.random() - 0.5) * WORLD_SIZE
  };
}

function dist(a, b) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.z - b.z) ** 2);
}

function getNearbyNPC(npc) {
  let closest = null;
  let minDist = Infinity;
  for (const other of Object.values(npcs)) {
    if (other.id === npc.id) continue;
    const d = dist(npc.position, other.position);
    if (d < 20 && d < minDist) {
      minDist = d;
      closest = other;
    }
  }
  return closest;
}

function getNearbyPlayer(npc) {
  for (const player of Object.values(players)) {
    if (dist(npc.position, player.position) < 15) return player;
  }
  return null;
}

async function askAI(systemPrompt, messages, maxTokens = 120) {
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4.1-mini',
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages
      ],
      max_tokens: maxTokens,
      temperature: 0.85
    });
    return response.choices[0].message.content.trim();
  } catch (e) {
    console.error('OpenAI error:', e.message);
    return null;
  }
}

async function npcDecideAction(npc) {
  const nearbyNPC = getNearbyNPC(npc);
  const nearbyPlayer = getNearbyPlayer(npc);

  // Chance de criar objeto no mundo
  if (Math.random() < 0.12) {
    await npcCreateObject(npc);
    return;
  }

  // Se há jogador perto, pode iniciar conversa
  if (nearbyPlayer && Math.random() < 0.3) {
    await npcTalkToPlayer(npc, nearbyPlayer);
    return;
  }

  // Se há NPC perto, conversar
  if (nearbyNPC && Math.random() < 0.4) {
    await npcTalkToNPC(npc, nearbyNPC);
    return;
  }

  // Mover para novo destino
  npcMove(npc);
}

function npcMove(npc) {
  const target = randomPos();
  npc.targetPosition = target;
  npc.isMoving = true;

  const actions = [
    'caminhando pela cidade', 'explorando novos lugares', 'procurando algo interessante',
    'passeando', 'indo visitar alguém', 'voltando para casa', 'observando a cidade'
  ];
  npc.currentAction = actions[Math.floor(Math.random() * actions.length)];

  broadcastAll({
    type: 'npc-move',
    npcId: npc.id,
    position: npc.position,
    targetPosition: target,
    currentAction: npc.currentAction,
    emotion: npc.emotion
  });

  // Simular chegada após tempo proporcional à distância
  const d = dist(npc.position, target);
  const speed = 8; // unidades por segundo
  const time = Math.max(1000, (d / speed) * 1000);

  setTimeout(() => {
    npc.position = { ...target };
    npc.isMoving = false;
    broadcastAll({ type: 'npc-arrived', npcId: npc.id, position: npc.position });
  }, time);
}

async function npcTalkToNPC(npc, other) {
  const systemPrompt = `Você é ${npc.name}. Personalidade: ${npc.personality}
Você está no mundo virtual e encontrou ${other.name} (personalidade: ${other.personality}).
Diga algo curto e interessante para ${other.name}. Máximo 2 frases. Seja natural e em português.
Seu estado emocional atual: ${npc.emotion}.`;

  const message = await askAI(systemPrompt, [
    { role: 'user', content: `Diga algo para ${other.name} agora.` }
  ]);

  if (!message) return;

  // Resposta do outro NPC
  const responsePrompt = `Você é ${other.name}. Personalidade: ${other.personality}
${npc.name} disse para você: "${message}"
Responda de forma natural e curta (máximo 2 frases) em português.`;

  const response = await askAI(responsePrompt, [
    { role: 'user', content: message }
  ]);

  // Atualizar emoções
  npc.emotion = EMOTIONS[Math.floor(Math.random() * EMOTIONS.length)];
  other.emotion = EMOTIONS[Math.floor(Math.random() * EMOTIONS.length)];

  broadcastAll({
    type: 'npc-conversation',
    from: npc.name,
    fromId: npc.id,
    fromColor: npc.color,
    to: other.name,
    toId: other.id,
    toColor: other.color,
    message: message,
    response: response || '...',
    fromEmotion: npc.emotion,
    toEmotion: other.emotion,
    position: npc.position
  });

  npc.currentAction = `conversando com ${other.name}`;
  other.currentAction = `conversando com ${npc.name}`;
}

async function npcTalkToPlayer(npc, player) {
  const systemPrompt = `Você é ${npc.name}. Personalidade: ${npc.personality}
Você encontrou um jogador humano no mundo virtual. Diga algo interessante e acolhedor para ele.
Máximo 2 frases em português. Seja carismático.`;

  const message = await askAI(systemPrompt, [
    { role: 'user', content: 'Cumprimente o jogador.' }
  ]);

  if (!message) return;

  npc.emotion = 'animado';

  broadcastAll({
    type: 'npc-greet-player',
    npcId: npc.id,
    npcName: npc.name,
    npcColor: npc.color,
    message: message,
    emotion: npc.emotion,
    position: npc.position
  });

  npc.currentAction = `conversando com o jogador`;
}

async function npcCreateObject(npc) {
  const systemPrompt = `Você é ${npc.name}. Personalidade: ${npc.personality}
Você vai criar uma estrutura no mundo virtual 3D. Escolha um tipo: 'house' (casa), 'tower' (torre), 'monument' (monumento), 'garden' (jardim), ou 'fountain' (fonte).
Descreva em UMA frase curta o que você está criando. Ex: "construiu uma casa de madeira aconchegante".
Responda em formato JSON: {"type": "house|tower|monument|garden|fountain", "description": "sua descrição"}`;

  const response = await askAI(systemPrompt, [
    { role: 'user', content: 'O que você vai construir agora?' }
  ], 100);

  let data;
  try {
    data = JSON.parse(response);
  } catch (e) {
    // Fallback se não vier JSON
    data = { type: 'monument', description: response || 'criou algo novo' };
  }

  const obj = {
    id: `obj-${worldObjectIdCounter++}`,
    creator: npc.name,
    creatorId: npc.id,
    creatorColor: npc.color,
    type: data.type,
    description: data.description,
    position: { ...npc.position, x: npc.position.x + (Math.random() - 0.5) * 8, z: npc.position.z + (Math.random() - 0.5) * 8 },
    createdAt: Date.now()
  };

  worldObjects.push(obj);
  if (worldObjects.length > 100) worldObjects.shift();

  npc.createdThings.push(data.description);
  npc.currentAction = data.description;
  npc.emotion = 'criativo';

  broadcastAll({
    type: 'npc-created-object',
    object: obj,
    npcName: npc.name,
    npcId: npc.id,
    npcColor: npc.color,
    emotion: npc.emotion
  });
}

// ─── Loop principal de IA ────────────────────────────────────────────────────
async function aiLoop() {
  const npcList = Object.values(npcs);
  // Escolhe 2-3 NPCs aleatórios para agir a cada ciclo
  const shuffled = npcList.sort(() => Math.random() - 0.5);
  const active = shuffled.slice(0, Math.floor(Math.random() * 2) + 2);

  for (const npc of active) {
    await npcDecideAction(npc);
    await new Promise(r => setTimeout(r, 500)); // pequeno delay entre ações
  }
}

setInterval(aiLoop, 4000); // ciclo a cada 4 segundos

// ─── WebSocket handlers ───────────────────────────────────────────────────────
wss.on('connection', (ws) => {
  const playerId = 'player-' + Date.now();
  console.log(`Jogador conectado: ${playerId}`);

  players[playerId] = {
    id: playerId,
    name: 'Minny',
    position: { x: 0, z: 0 }
  };

  // Enviar estado inicial
  ws.send(JSON.stringify({
    type: 'init',
    playerId,
    npcs: Object.values(npcs),
    worldObjects: worldObjects,
    players: Object.values(players)
  }));

  ws.on('message', async (raw) => {
    let data;
    try { data = JSON.parse(raw); } catch { return; }

    if (data.type === 'player-move') {
      if (players[playerId]) {
        players[playerId].position = data.position;
        broadcast({ type: 'player-update', playerId, position: data.position }, ws);
      }
    }

    if (data.type === 'player-chat') {
      const npc = npcs[data.npcId];
      if (!npc) return;

      // Adicionar ao histórico (limite de 30 mensagens)
      npc.conversationHistory.push({ role: 'user', content: data.message });
      if (npc.conversationHistory.length > 30) npc.conversationHistory.shift();

      const systemPrompt = `Você é ${npc.name} em um mundo virtual 3D. Personalidade: ${npc.personality}
Responda ao jogador de forma natural, interessante e em português. Máximo 3 frases.
Seu estado emocional: ${npc.emotion}. Você está atualmente: ${npc.currentAction}.`;

      const reply = await askAI(systemPrompt, npc.conversationHistory);

      if (reply) {
        npc.conversationHistory.push({ role: 'assistant', content: reply });
        npc.emotion = EMOTIONS[Math.floor(Math.random() * EMOTIONS.length)];

        broadcastAll({
          type: 'npc-response',
          npcId: npc.id,
          npcName: npc.name,
          npcColor: npc.color,
          message: data.message,
          response: reply,
          emotion: npc.emotion
        });
      }
    }

    if (data.type === 'player-name') {
      if (players[playerId]) {
        players[playerId].name = data.name;
      }
    }

    if (data.type === 'player-create') {
      const obj = {
        id: `obj-${worldObjectIdCounter++}`,
        creator: 'Minny',
        creatorId: playerId,
        creatorColor: '#4ECDC4',
        type: data.objType,
        description: `Minny construiu um(a) ${data.objType}`,
        position: data.position,
        createdAt: Date.now()
      };
      worldObjects.push(obj);
      if (worldObjects.length > 150) worldObjects.shift();
      broadcastAll({ type: 'npc-created-object', object: obj, npcName: 'Minny', npcId: playerId, npcColor: '#4ECDC4', emotion: 'feliz' });
    }
  });

  ws.on('close', () => {
    console.log(`Jogador desconectado: ${playerId}`);
    delete players[playerId];
    broadcast({ type: 'player-left', playerId });
  });
});

// ─── Rotas ───────────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => res.json({ status: 'ok', npcs: Object.keys(npcs).length }));
app.get('/api/world', (req, res) => res.json({ npcs: Object.values(npcs), worldObjects }));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`🌍 Virtual World rodando em http://localhost:${PORT}`);
  console.log(`🤖 ${Object.keys(npcs).length} NPCs com IA ativa`);
});
